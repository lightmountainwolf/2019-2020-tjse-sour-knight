<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="tileset" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="54" columns="9">
 <image source="tileset.png" width="304" height="224"/>
</tileset>
