<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="房子" tilewidth="32" tileheight="32" tilecount="216" columns="8">
 <image source="房子.png" width="256" height="864"/>
</tileset>
