<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="元气骑士" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="Tiles (1)_wps图片.png" width="96" height="96"/>
 <tile id="0">
  <properties>
   <property name="move" value="false"/>
   <property name="type" value="我是图块属性"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="move" value="false"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="move" value="true"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="move" value="true"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="move" value="false"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="move" value="false"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="move" value="false"/>
  </properties>
 </tile>
</tileset>
