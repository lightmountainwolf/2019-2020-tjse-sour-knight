#include "pauseControl.h"
#include "PauseSetting.h"
#include "StartPauseScene.h"
#include "SoundAndMusic.h"
USING_NS_CC;

Scene* Pause::createScene()
{
	return Pause::create();
}

bool Pause::init()
{
	if (!Scene::init())
	{
		return false;
	}
	auto visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();

	//��ͣ���
	auto background1 = Sprite::create("tablePause.png");
	background1->setAnchorPoint(Point(0.5,0.5));
	background1->setPosition(Point(visibleSize.width/2,visibleSize.height/2));
	addChild(background1);


	//����ͷ��
	//auto player = setPlayer();
	auto player = Sprite::create("knight.png");
	float length = 100;
	auto playerSize = player->getContentSize();
	float scaleSize = length / playerSize.width;
	player->setScale(scaleSize);

	player->setAnchorPoint(Point(0,0));
	player->setPosition(Point(381, 960 - 409));
	addChild(player);


	//menu-setting
	MenuItemImage* setting = MenuItemImage::create(
		"buttonSet.png","buttonSetClicked.png", CC_CALLBACK_1(Pause::menuSettingCallback, this));
	setting->setAnchorPoint(Vec2(0, 0));
	setting->setPosition(Vec2(387, 960-636));

	//menu-continue
	MenuItemImage* continueButton = MenuItemImage::create(
		"buttonContinue.png", "buttonContinueClicked.png", CC_CALLBACK_1(Pause::menuContinueCallback, this));
	continueButton->setAnchorPoint(Vec2(0, 0));
	continueButton->setPosition(Vec2(560, 960 - 636));

	//menu-home
	MenuItemImage* home = MenuItemImage::create(
		"buttonHome.png", "buttonHomeClicked.png", CC_CALLBACK_1(Pause::menuHomeCallback, this));
	home->setAnchorPoint(Vec2(0, 0));
	home->setPosition(Vec2(789, 960 - 636));

	/*//sound control
	//��Ч��ť
	//bug û�и��µ�ǰ״̬��ͼƬ��
	//bug û�а�setting��ʱ��ֻ������״̬
	auto soundOnMenuItem = MenuItemImage::create("buttonSound.png", "buttonSound.png");
	auto soundOffMenuItem = MenuItemImage::create("buttonSoundClicked.png", "buttonSoundClicked.png");
	auto soundToggleMenuItem = MenuItemToggle::createWithCallback(CC_CALLBACK_1(Pause::menuSoundToggleCallback, this),
		                                                                    soundOnMenuItem, soundOffMenuItem, NULL);
	soundToggleMenuItem->setOpacity(0);
	soundToggleMenuItem->setAnchorPoint(Vec2(0, 0));
	soundToggleMenuItem->setPosition(Vec2(58,50));

	//music control
	//���ְ�ť
	//bug û�и��µ�ǰ״̬��ͼƬ��
	//bug û�а�setting��ʱ��ֻ������״̬
	auto musicOnMenuItem = MenuItemImage::create("buttonMusic.png", "buttonMusic.png");
	auto musicOffMenuItem = MenuItemImage::create("buttonMusicClicked.png", "buttonMusicClicked.png");
	auto musicToggleMenuItem = MenuItemToggle::createWithCallback(CC_CALLBACK_1(Pause::menuMusicToggleCallback, this),
		                                                            musicOnMenuItem, musicOffMenuItem, NULL);
	musicToggleMenuItem->setOpacity(0);
	musicToggleMenuItem->setAnchorPoint(Vec2(0, 0));
	musicToggleMenuItem->setPosition(Vec2(217,50));*/


	Menu* menu = Menu::create(setting,continueButton,home, NULL);
	menu->setPosition(Vec2::ZERO);
	this->addChild(menu);
	return true;
}

void Pause::onEnter()
{
	Scene::onEnter();
	log("PauseControl onEnter");
}

void Pause::onEnterTransitionDidFinish()
{
	Scene::onEnterTransitionDidFinish();
	log("PauseControl onEnterTransitionDidFinish");
	if (doContinueGame == true)
	{
		doContinueGame = false;
		Director::getInstance()->popScene();
	}
}

void Pause::onExit()
{
	Scene::onExit();
	log("PauseControl onExit");
}

void Pause::onExitTransitionDidStart()
{
	Scene::onExitTransitionDidStart();
	log("PauseControl onExitTransitionDidStart");
}

void Pause::cleanup()
{
	Scene::cleanup();
	log("PauseControl cleanup");
}

void Pause::menuSettingCallback(cocos2d::Ref* pSender)
{
	auto PauseSettingScene = PauseSetting::createScene();
	Director::getInstance()->pushScene(PauseSettingScene);
}

void Pause::menuContinueCallback(cocos2d::Ref* pSender)
{
	Director::getInstance()->popScene();
}

void Pause::menuHomeCallback(cocos2d::Ref* pSender)
{
	auto startPauseScene = StartPause::createScene();
	Director::getInstance()->pushScene(startPauseScene);
}