
#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"



USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    if (!Scene::init())
        return false;
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()-> getVisibleOrigin();


    /*auto background = Sprite::create("menu/background.png");
    background->setAnchorPoint(Vec2::ZERO);
    this->addChild(background,0);*/

    /*auto bg = Sprite::create("background.png", Rect(0, 0, visibleSize.width, visibleSize.height));
    Texture2D::TexParams tp = { GL_LINEAR < GL_LINEAR,GL_REPEAT,GL_REPEAT };
    bg->getTexture()->setTexParameters(tp);
    bg->setPosition(Vec2::ZERO);
    //bg->setPosition(origin + Vec2(visibleSize.width / 2, visibleSize.height / 2) + Vec2(-120, 120));
    addChild(bg, 0);*/


    Sprite* boxA = Sprite::create("block1.png");
    boxA->setPosition(origin + Vec2(visibleSize.width / 2, visibleSize.height / 2) + Vec2(-120, 120));
    addChild(boxA, 10,kBoxA_Tag);



    Sprite* boxB = Sprite::create("block2.png");
    boxB->setPosition(origin + Vec2(visibleSize.width / 2, visibleSize.height / 2) );
    addChild(boxB, 10, kBoxB_Tag);
        

    Sprite* boxC = Sprite::create("treasureBox.png");
    boxC->setPosition(origin + Vec2(visibleSize.width / 2, visibleSize.height / 2) + Vec2(120, 160));
    addChild(boxC, 10, kBoxC_Tag);

    return true;
   
}






void HelloWorld::menuCloseCallback(Ref* pSender)
{

    Director::getInstance()->end();


}


void HelloWorld::onEnter()
{
    Scene::onEnter();
    log("HelloWorld onEnter");
    auto listener = EventListenerTouchOneByOne::create();

    listener->setSwallowTouches(true);
    listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::touchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(HelloWorld::touchMoved, this);
    listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::touchEnded, this);


    //ע�������
    EventDispatcher* eventDispatcher = Director::getInstance()->getEventDispatcher();

    eventDispatcher->addEventListenerWithSceneGraphPriority(listener, getChildByTag(kBoxA_Tag));
    eventDispatcher->addEventListenerWithSceneGraphPriority(listener->clone(), getChildByTag(kBoxB_Tag));
    eventDispatcher->addEventListenerWithSceneGraphPriority(listener->clone(), getChildByTag(kBoxC_Tag));

}


void HelloWorld::onExit()
{
    Scene::onExit();
    log("HelloWorld onExit");
    Director::getInstance()->getEventDispatcher()->removeAllEventListeners();
}


bool HelloWorld::touchBegan(Touch* touch, Event* event)
{
    //��ȡ�¼����󶨵�target
    auto target = static_cast<Sprite*>(event->getCurrentTarget());
    Vec2 locationInNode = target->convertToNodeSpace(touch->getLocation());
    Size s = target->getContentSize();
    Rect rect = Rect(0, 0, s.width, s.height);

    //������Χ�жϼ��
    if (rect.containsPoint(locationInNode))
    {
        log("sprite x=%f,y=%f", locationInNode.x, locationInNode.y);
        log("sprite tag=%d", target->getTag());
        target->runAction(ScaleBy::create(0.6f, 1.06f));
        return true;
    }
    return false;
}

void HelloWorld::touchMoved(Touch* touch, Event* event)
{
    log("onTouchMoved");
    auto target = static_cast<Sprite*>(event->getCurrentTarget());
    target->setPosition(target->getPosition() + touch->getDelta());
}

void HelloWorld::touchEnded(Touch* touch, Event* event)
{
    log("onTouchEnded");
    auto target = static_cast<Sprite*>(event->getCurrentTarget());
    log("sprite onTouchesEnded..");

    Vec2 locationInNode = target->convertToNodeSpace(touch->getLocation());
    Size s = target->getContentSize();
    Rect rect = Rect(0, 0, s.width, s.height);
    //������Χ�жϼ��
    if (rect.containsPoint(locationInNode))
    {
        log("sprite x=&f,y=&f", locationInNode.x, locationInNode.y);
        log("sprite,tag=%d", target->getTag());
        target->runAction(ScaleTo::create(0.6f, 1.0f));
    }




}