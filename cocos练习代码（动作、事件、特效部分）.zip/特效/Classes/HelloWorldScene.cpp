
#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    if (!Scene::init())
        return false;
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()-> getVisibleOrigin();

    auto bg = Sprite::create("menu/background.png");
    bg->setPosition((Vec2(origin.x + visibleSize.width / 2,
        origin.y + visibleSize.height / 2)));
    this->addChild(bg);

    /*

    kFlipX3D = 101,
kPageTurn3D,
kLens3D,
kShaky3D,
kWaves3D,
kJumpTiles3D,
kShakyTiles3D,
kWavesTiles3D
*/

    auto pItmLabel1 = Label::createWithTTF("FlipX3D","fonts/arial.ttf",36);
    auto pItmMenu1 = MenuItemLabel::create(pItmLabel1, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu1->setTag(kFlipX3D);

     auto pItmLabel2 = Label::createWithTTF("PageTurn3D", "fonts/arial.ttf", 36);
     auto pItmMenu2 = MenuItemLabel::create(pItmLabel2, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu2->setTag(kPageTurn3D);

     auto pItmLabel3 = Label::createWithTTF("Lens3D", "fonts/arial.ttf", 36);
     auto pItmMenu3= MenuItemLabel::create(pItmLabel3, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu3->setTag(kLens3D);

     auto pItmLabel4 = Label::createWithTTF("Shaky3D", "fonts/arial.ttf", 36);
     auto pItmMenu4 = MenuItemLabel::create(pItmLabel4, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu4->setTag(kShaky3D);

     auto pItmLabel5 = Label::createWithTTF("Waves3D", "fonts/arial.ttf", 36);
     auto pItmMenu5 = MenuItemLabel::create(pItmLabel5, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu5->setTag(kWaves3D);

     auto pItmLabel6= Label::createWithTTF("JumpTiles3D", "fonts/arial.ttf", 36);
     auto pItmMenu6 = MenuItemLabel::create(pItmLabel6, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu6->setTag(kJumpTiles3D);

     auto pItmLabel7 = Label::createWithTTF("ShakyTiles3D", "fonts/arial.ttf", 36);
     auto pItmMenu7 = MenuItemLabel::create(pItmLabel7, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu7->setTag(kShakyTiles3D);

     auto pItmLabel8 = Label::createWithTTF("WavesTiles3D", "fonts/arial.ttf", 36);
     auto pItmMenu8 = MenuItemLabel::create(pItmLabel8, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
     pItmMenu8->setTag(kWavesTiles3D);

   
     auto mn = Menu::create(pItmMenu1, pItmMenu2, pItmMenu3, pItmMenu4, pItmMenu5, pItmMenu6,
         pItmMenu7, pItmMenu8,NULL);

     mn->alignItemsInColumns(2, 2, 2, 2, 2, NULL);
   // mn->alignItemsVertically();
    this->addChild(mn);
    return true;


   


}


void HelloWorld::OnClickMenu(Ref* pSender)
{
    MenuItem* nmitem = (MenuItem*)pSender;

    auto sc = Scene::create();
    auto layer = MyAction::create();
    layer->setTag(nmitem->getTag());

    sc->addChild(layer);

    auto reScene = TransitionSlideInR::create(1.0f, sc);
    Director::getInstance()->replaceScene(reScene);
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{

    Director::getInstance()->end();


}
