
#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    if (!Scene::init())
        return false;
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()-> getVisibleOrigin();

    auto bg = Sprite::create("menu/background.png");
    bg->setPosition((Vec2(origin.x + visibleSize.width / 2,
        origin.y + visibleSize.height / 2)));
    this->addChild(bg);



    auto pItmLabel1 = Label::createWithTTF("MoveTo","fonts/arial.ttf",36);
    auto pItmMenu1 = MenuItemLabel::create(pItmLabel1, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
 
    pItmMenu1->setTag(kMoveTo);

 
    auto pItmLabel2 = Label::createWithTTF("MoveBy", "fonts/arial.ttf", 36);
    auto pItmMenu2 = MenuItemLabel::create(pItmLabel2, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu2->setTag(kMoveBy);

    auto pItmLabel3 = Label::createWithTTF("JumpTo", "fonts/arial.ttf", 36);
    auto pItmMenu3 = MenuItemLabel::create(pItmLabel3, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu3->setTag(kJumpTo);

    auto pItmLabel4 = Label::createWithTTF("JumpBy", "fonts/arial.ttf", 36);
    auto pItmMenu4 = MenuItemLabel::create(pItmLabel4, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu4->setTag(kJumpBy);
    auto pItmLabel5 = Label::createWithTTF("BezierBy", "fonts/arial.ttf", 36);
    auto pItmMenu5 = MenuItemLabel::create(pItmLabel5, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu5->setTag(kBezierBy);

    auto pItmLabel6 = Label::createWithTTF("ScaleTo", "fonts/arial.ttf", 36);
    auto pItmMenu6 = MenuItemLabel::create(pItmLabel6, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu1->setTag(kScaleTo);
    auto pItmLabel7 = Label::createWithTTF("ScaleBy", "fonts/arial.ttf", 36);
    auto pItmMenu7 = MenuItemLabel::create(pItmLabel7, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu7->setTag(kScaleBy);
    auto pItmLabel8 = Label::createWithTTF("RotateTo", "fonts/arial.ttf", 36);
    auto pItmMenu8 = MenuItemLabel::create(pItmLabel8, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu8->setTag(kRotateTo);
    auto pItmLabel9 = Label::createWithTTF("RotateBy", "fonts/arial.ttf", 36);
    auto pItmMenu9 = MenuItemLabel::create(pItmLabel9, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu1->setTag(kRotateBy);
    auto pItmLabel10 = Label::createWithTTF("Blink", "fonts/arial.ttf", 36);
    auto pItmMenu10 = MenuItemLabel::create(pItmLabel10, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu10->setTag(kBlink);

    auto pItmLabel11 = Label::createWithTTF("TintTo", "fonts/arial.ttf", 36);
    auto pItmMenu11= MenuItemLabel::create(pItmLabel11, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu11->setTag(kTintTo);
    auto pItmLabel12= Label::createWithTTF("TintyBy", "fonts/arial.ttf", 36);
    auto pItmMenu12 = MenuItemLabel::create(pItmLabel12, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu12->setTag(kTintBy);
    auto pItmLabel13 = Label::createWithTTF("FadeTo", "fonts/arial.ttf", 36);
    auto pItmMenu13 = MenuItemLabel::create(pItmLabel13, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu13->setTag(kFadeTo);
    auto pItmLabel14 = Label::createWithTTF("FadeIn", "fonts/arial.ttf", 36);
    auto pItmMenu14 = MenuItemLabel::create(pItmLabel14, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu14->setTag(kFadeIn);
    auto pItmLabel15 = Label::createWithTTF("FadeOut", "fonts/arial.ttf", 36);
    auto pItmMenu15 = MenuItemLabel::create(pItmLabel15, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    pItmMenu15->setTag(kFadeOut);

    auto mn = Menu::create(pItmMenu1, pItmMenu2, pItmMenu3, pItmMenu4, pItmMenu5, pItmMenu6, pItmMenu7, pItmMenu8, pItmMenu9,
        pItmMenu10, pItmMenu11, pItmMenu12, pItmMenu13, pItmMenu14, pItmMenu15, NULL);
    mn->alignItemsInColumns(3, 3, 3, 3, 3, NULL);
    this->addChild(mn);
    return true;


   


}


void HelloWorld::OnClickMenu(Ref* pSender)
{
    MenuItem* nmitem = (MenuItem*)pSender;

    auto sc = Scene::create();
    auto layer = MyAction::create();
    layer->setTag(nmitem->getTag());

    sc->addChild(layer);

    auto reScene = TransitionSlideInR::create(1.0f, sc);
    Director::getInstance()->replaceScene(reScene);
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{

    Director::getInstance()->end();


}
