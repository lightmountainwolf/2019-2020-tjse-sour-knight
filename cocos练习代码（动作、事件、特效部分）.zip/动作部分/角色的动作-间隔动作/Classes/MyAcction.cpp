#include"MyAction.h"

bool MyAction::init()
{
	if (!Layer::init())
		return false;

	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto bg = Sprite::create("menu/background2.png");

	bg->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(bg);

	sprite = Sprite::create("menu/knight.png");
	sprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(sprite);

	auto backMenuItem = MenuItemImage::create("menu/exit-up.png","menu/exit-down.png",CC_CALLBACK_1(MyAction::backMenu,this));
	backMenuItem->setPosition(Director::getInstance()->convertToGL(Vec2(120, 100)));

	auto goMenuItem = MenuItemImage::create("menu/continue-up.png", "menu/continue-down.png", CC_CALLBACK_1(MyAction::goMenu, this));

	goMenuItem->setPosition(visibleSize.width / 2, 100);

	Menu* mn = Menu::create(backMenuItem, goMenuItem, NULL);

	mn->setPosition(Vec2::ZERO);
	this->addChild(mn);
	this->hiddenFlag = true;
	return true;

}


void MyAction::backMenu(Ref* pSender)
{
	auto sc = HelloWorld::createScene();
	auto reScene = TransitionSlideInL::create(1.0f, sc);
	Director::getInstance()->replaceScene(reScene);
}


void MyAction::goMenu(Ref* pSender)
{
	log("Tag=%i", this->getTag());
	auto size = Director::getInstance()->getVisibleSize();
	
	ccBezierConfig bezier;

	switch (this->getTag())
	{
	case kMoveTo:
		sprite->runAction(MoveTo::create(2, Vec2(size.width - 50, size.height - 50)));
		break;
	case kMoveBy:
		sprite->runAction(MoveBy::create(2, Vec2(-50, -50)));
		break;
	case kJumpTo:
		sprite->runAction(JumpTo::create(2, Vec2(150, 50),30,5));
		break;
	case kJumpBy:
		sprite->runAction(JumpBy::create(2, Vec2(100,100),30,5));
		break;
	case kBezierBy:
		bezier.controlPoint_1 = Vec2(0, size.height / 2);
		bezier.controlPoint_2 = Vec2(300, -size.height / 2);
		bezier.endPosition = Vec2(100, 100);
		sprite->runAction(BezierBy::create(3, bezier));
		break;
	case kScaleTo:
		sprite->runAction(ScaleTo::create(2,4));
		break;
	case kScaleBy:
		sprite->runAction(ScaleBy::create(2,0.5));
		break;
	case kRotateTo:
		sprite->runAction(RotateTo::create(2,180));
		break;
	case kRotateBy:
		sprite->runAction(RotateTo::create(2,-180));
		break;
	case kBlink:
		sprite->runAction(Blink::create(3,5));
		break;
	case kTintTo:
		sprite->runAction(TintTo::create(2,255,0,0));
		break;
	case kTintBy:
		sprite->runAction(TintBy::create(0.5,0,255,255));
		break;
	case kFadeTo:
		sprite->runAction(FadeTo::create(1,80));
		break;
	case kFadeIn:
		sprite->runAction(FadeIn::create(1));
		break;
	case kFadeOut:
		sprite->runAction(FadeOut::create(1));
		break;
	default:
		break;
	}

	
}