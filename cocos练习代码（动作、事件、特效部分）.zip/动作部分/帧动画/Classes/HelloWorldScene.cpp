
#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"



USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    if (!Scene::init())
        return false;
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()-> getVisibleOrigin();




    auto background = Sprite::create("menu/background.png");
    background->setAnchorPoint(Vec2::ZERO);
    this->addChild(background,0);


   auto frameCache = SpriteFrameCache::getInstance();
    frameCache->addSpriteFramesWithFile("knight1.plist");


    auto sprite = Sprite::create("menu/knight.png");

    sprite->setPosition((Vec2(visibleSize.width / 2, visibleSize.height / 2)));

    this->addChild(sprite);


    Vector<SpriteFrame*>vec;
    char name[20] = { 0 };

    for (int i = 1; i <= 2; i++)
    {
        sprintf(name, "knight%d.png", i);
        vec.pushBack(frameCache->getSpriteFrameByName(name));
    }

    auto animation = Animation::createWithSpriteFrames(vec);
    animation->setDelayPerUnit(0.5f);
    animation->setLoops(-1);
    animation->setRestoreOriginalFrame(true);
    auto animate = Animate::create(animation);
    sprite->runAction(animate);

 
        


    return true;
   
}














void HelloWorld::menuCloseCallback(Ref* pSender)
{

    Director::getInstance()->end();


}
