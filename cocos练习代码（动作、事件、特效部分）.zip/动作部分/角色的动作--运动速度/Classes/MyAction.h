#pragma once
#ifndef _MY_ACTION_SCENE_H
#define _MY_ACTION_SCENE_H
#include"cocos2d.h"
#include "HelloWorldScene.h"

USING_NS_CC;

class MyAction :public Layer
{
	bool hiddenFlag;
	Sprite* sprite;
public:
	static Scene* createScene();
	virtual bool init();

	CREATE_FUNC(MyAction);

	void goMenu(Ref* pSender);
	void backMenu(Ref* pSender);

;
};


#endif