
#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    if (!Scene::init())
        return false;
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()-> getVisibleOrigin();

    auto bg = Sprite::create("menu/background.png");
    bg->setPosition((Vec2(origin.x + visibleSize.width / 2,
        origin.y + visibleSize.height / 2)));
    this->addChild(bg);

    auto placeLabel = Label::createWithTTF("Place","fonts/arial.ttf",36);
    auto placeMenu = MenuItemLabel::create(placeLabel, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));
 
    placeMenu->setTag(PLACE_TAG);

 




    auto flipXLabel = Label::createWithTTF( "FlipX","fonts/arial.ttf",36);
    auto flipXMenu = MenuItemLabel::create(flipXLabel, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    flipXMenu->setTag(FLIPX_TAG);

    auto flipYLabel = Label::createWithTTF("FlipY", "fonts/arial.ttf",  36);
    auto flipYMenu = MenuItemLabel::create(flipYLabel , CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    flipYMenu->setTag(FLIPY_TAG);

    auto hideLabel = Label::createWithTTF("Hide or show","fonts/arial.ttf",36);
    auto hideMenu = MenuItemLabel::create(hideLabel, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    hideMenu->setTag(HIDE_SHOW_TAG);


    auto toggleLabel = Label::createWithTTF("Toggle", "fonts/arial.ttf", 36);
    auto toggleMenu = MenuItemLabel::create(toggleLabel, CC_CALLBACK_1(HelloWorld::OnClickMenu, this));

    toggleMenu->setTag(TOGGLE_TAG);

    auto mn = Menu::create(placeMenu, flipXMenu, flipYMenu, hideMenu, toggleMenu, NULL);
 
  
    mn->alignItemsVertically();
    this->addChild(mn);

    return true;


}


void HelloWorld::OnClickMenu(Ref* pSender)
{
    MenuItem* nmitem = (MenuItem*)pSender;

    auto sc = Scene::create();
    auto layer = MyAction::create();
    layer->setTag(nmitem->getTag());

    sc->addChild(layer);

    auto reScene = TransitionSlideInR::create(1.0f, sc);
    Director::getInstance()->replaceScene(reScene);
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{

    Director::getInstance()->end();


}
