#include"MyAction.h"

bool MyAction::init()
{
	if (!Layer::init())
		return false;

	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto bg = Sprite::create("menu/background2.png");

	bg->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(bg);

	sprite = Sprite::create("menu/knight.png");
	sprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(sprite);

	auto backMenuItem = MenuItemImage::create("menu/exit-up.png","menu/exit-down.png",CC_CALLBACK_1(MyAction::backMenu,this));
	backMenuItem->setPosition(Director::getInstance()->convertToGL(Vec2(120, 100)));

	auto goMenuItem = MenuItemImage::create("menu/continue-up.png", "menu/continue-down.png", CC_CALLBACK_1(MyAction::goMenu, this));

	goMenuItem->setPosition(visibleSize.width / 2, 100);

	Menu* mn = Menu::create(backMenuItem, goMenuItem, NULL);

	mn->setPosition(Vec2::ZERO);
	this->addChild(mn);
	this->hiddenFlag = true;
	return true;

}


void MyAction::backMenu(Ref* pSender)
{
	auto sc = HelloWorld::createScene();
	auto reScene = TransitionSlideInL::create(1.0f, sc);
	Director::getInstance()->replaceScene(reScene);
}


void MyAction::goMenu(Ref* pSender)
{
	log("Tag=%i", this->getTag());
	switch (this->getTag())
	{
	case kSequence:
		this->OnSequence(pSender);
		break;
	case kSpawn:
		this->OnSpawn(pSender);
		break;
	case kRepeat:
		this->OnRepeat(pSender);
		break;
	case kRepeatForeverl:
		this->OnRepeatForever(pSender);
		break;
	case kReverse:
		this->OnReverse(pSender);
		break;
	default:
		break;

	}
	
}


void MyAction::OnSequence(Ref* pSender)//��˳��ִ�ж���
{
	auto size = Director::getInstance()->getVisibleSize();
	Vec2 p = Vec2(size.width / 2, 200);


	auto* ac0 = (FiniteTimeAction*)sprite->runAction(Place::create(p));
	auto* ac1 = (FiniteTimeAction*)sprite->runAction(MoveTo::create(2, Vec2(size.width - 130, size.height - 200)));
	auto* ac2 = (FiniteTimeAction*)sprite->runAction(JumpBy::create(2, Vec2(8, 8), 6, 3));
	auto* ac3 = (FiniteTimeAction*)sprite->runAction(Blink::create(2, 3));
	auto* ac4 = (FiniteTimeAction*)sprite->runAction(TintBy::create(0.5, 0, 255, 255));
	sprite->runAction(Sequence::create(ac0, ac1, ac2, ac3, ac4, ac0, NULL));
}


void MyAction::OnSpawn(Ref* pSender)
{
	auto size = Director::getInstance()->getVisibleSize();
	Vec2 p = Vec2(size.width / 2, 200);

	sprite->setRotation(0);
	sprite->setPosition(p);

	
	auto* ac1 = (FiniteTimeAction*)sprite->runAction(MoveTo::create(2, Vec2(size.width - 100, size.height - 100)));
	auto* ac2 = (FiniteTimeAction*)sprite->runAction(RotateTo::create(2,40));

	sprite->runAction(Sequence::create( ac1, ac2, NULL));
}

void MyAction::OnRepeat(Ref* pSender)//�����ظ�����
{
	auto size = Director::getInstance()->getVisibleSize();
	Vec2 p = Vec2(size.width / 2, 200);

	sprite->setRotation(0);
	sprite->setPosition(p);

	
	auto* ac1 = (FiniteTimeAction*)sprite->runAction(MoveTo::create(2, Vec2(size.width - 100, size.height - 100)));
	auto* ac2 = (FiniteTimeAction*)sprite->runAction(JumpBy::create(2, Vec2(10, 10), 20, 5));
	auto* ac3 = (FiniteTimeAction*)sprite->runAction(JumpBy::create(2,Vec2(-10,-10),20, 3));

	ActionInterval* seq = Sequence::create(ac1, ac2, ac3, NULL);

	sprite->runAction(Repeat::create(seq,3));
}

void MyAction::OnRepeatForever(Ref* pSender)//�����ظ�����
{
	auto size = Director::getInstance()->getVisibleSize();
	Vec2 p = Vec2(size.width / 2, 500);
	sprite->setRotation(0);
	sprite->setPosition(p);

	ccBezierConfig bezier;
	bezier.controlPoint_1 = Vec2(0, size.height / 2);
	bezier.controlPoint_2 = Vec2(10, -size.height / 2);
	bezier.endPosition = Vec2(10, 20);


	auto* ac1 = (FiniteTimeAction*)sprite->runAction(BezierBy::create(2,bezier));
	auto* ac2 = (FiniteTimeAction*)sprite->runAction(TintBy::create(0.5,0,255,255));

	auto* ac1Reverse = ((ActionInterval*)ac1)->reverse();
	auto* ac2Repeat = (FiniteTimeAction*)sprite->runAction(Repeat::create((ActionInterval*)ac2, 4));


	auto* ac3 = (FiniteTimeAction*)sprite->runAction(Spawn::create(ac1,ac2Repeat, NULL));
	auto* ac4 = (FiniteTimeAction*)sprite->runAction(Spawn::create(ac1Reverse,ac2Repeat,NULL));
	
	ActionInterval* seq = Sequence::create(ac3, ac4, NULL);
	sprite->runAction(RepeatForever::create(seq));
}


void MyAction::OnReverse(Ref* pSender)
{
	auto size = Director::getInstance()->getVisibleSize();
	Vec2 p = Vec2(size.width / 2, 300);

	sprite->setRotation(0);
	sprite->setPosition(p);


	auto* ac1 = (FiniteTimeAction*)sprite->runAction(MoveBy::create(2,Vec2(40,60)));
	auto* ac2 = ac1->reverse();

	ActionInterval* seq = Sequence::create(ac1, ac2, NULL);

	sprite->runAction(Repeat::create(seq,2));
}