<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="英雄传说地图-CZ_爱给网_aigei_com" tilewidth="32" tileheight="32" tilecount="200" columns="8">
 <image source="石头房子.png" width="256" height="800"/>
</tileset>
