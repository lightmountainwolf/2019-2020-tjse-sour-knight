<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="mainlevbuild" tilewidth="32" tileheight="32" tilecount="414" columns="18">
 <grid orientation="orthogonal" width="8" height="8"/>
 <image source="mainlevbuild.png" width="592" height="736"/>
</tileset>
