#include"Knight.h"



 bool Knight::init(const std::string& filename, Weapon* weapon)
{
     if (!Sprite::initWithFile(filename))
         return false;
     else
     {
         /*��ʿ��ɫ�ĳ�ʼ״̬Ϊ��
         HP��7
         Armor:6
         MP:200
         */
         setHP(HP_OF_KNIGHT);
         setArmor(ARMOR_OF_KNIGHT);
         setMP(MP_OF_KNIGHT);
         setAttackMode(weapon->getAttackMode());
         setAttackRadius(weapon->getAttackMode());
         setMPConsuming(weapon->getMPConsuming());
     }
}

 Knight* Knight::create(const std::string& filename, Weapon* weapon)
{
     Knight* knight = new Knight();

     if (knight && knight->init(filename, weapon))
     {
         knight->autorelease();

         /////////////////////////////////////////////////////////////////////
         auto herocache = SpriteFrameCache::getInstance();
         herocache->addSpriteFramesWithFile("Heroes/knightMoving.plist");
         Vector<SpriteFrame*>vector;
         char name[40];
         memset(name, 0, 40);
         for (int i = 0; i < 2; i++)
         {
             sprintf(name, "knightMoving%04d", i);
             vector.pushBack(herocache->getSpriteFrameByName(name));
         }
         Animation* moveAnimation = Animation::createWithSpriteFrames(vector, 0.3f);
         Animate* moveAnimate = Animate::create(moveAnimation);

         knight->runAction(RepeatForever::create(moveAnimate));
         ////////////////////////////////////////////////////////////////////////////////
         return knight;
     }
     else
     {
         CC_SAFE_DELETE(knight);
         return nullptr;
     }
}