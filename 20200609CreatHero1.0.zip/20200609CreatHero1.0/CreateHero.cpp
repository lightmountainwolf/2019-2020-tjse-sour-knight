#include "CreateHero.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;
//ʹ��ǰ��#include "CreateHero.h"
/*���ԬB��д���HelloWorldScene��ģ���µĳ�����init������������
��ԭ���� ����player = Sprite::create()������޸ĳ�
float playerLength = 80;
�������ѡ����knight��д�����setKnight�����ѡ����coolguy����ô��д�����setCoolguy��
player = setKnight(x,y,playerLength);
player = setCoolguy(x, y, playerLength);									
this->addChild(player)��*/

Sprite* setKnight(float x, float y, float length)
{
	auto hero = Sprite::create("Heroes/knight.png");

	hero->setPosition(x, y);

	auto spriteSize = hero->getContentSize();
	float scaleSize = length / spriteSize.width;
	hero->setScale(scaleSize);

	auto herocache = SpriteFrameCache::getInstance();
	herocache->addSpriteFramesWithFile("Heroes/knightMoving.plist");
	Vector<SpriteFrame*>vector;
	char name[40];
	memset(name, 0, 40);
	for (int i = 0; i < 2; i++)
	{
		sprintf(name, "knightMove%04d", i);
		vector.pushBack(herocache->getSpriteFrameByName(name));
	}
	Animation* moveAnimation = Animation::createWithSpriteFrames(vector, 0.3f);
	Animate* moveAnimate = Animate::create(moveAnimation);

	hero->runAction(RepeatForever::create(moveAnimate));

	return hero;
}

Sprite* setCoolguy(float x, float y, float length)
{
	auto hero = Sprite::create("Heroes/coolguy.png");

	hero->setPosition(x, y);

	auto spriteSize = hero->getContentSize();
	float scaleSize = length / spriteSize.width;
	hero->setScale(scaleSize);

	auto herocache = SpriteFrameCache::getInstance();
	herocache->addSpriteFramesWithFile("Heroes/coolGuyMove.plist");
	Vector<SpriteFrame*>vector;
	char name[40];
	memset(name, 0, 40);
	for (int i = 0; i < 2; i++)
	{
		sprintf(name, "coolGuyMove%04d", i);
		vector.pushBack(herocache->getSpriteFrameByName(name));
	}
	Animation* moveAnimation = Animation::createWithSpriteFrames(vector, 0.3f);
	Animate* moveAnimate = Animate::create(moveAnimation);

	hero->runAction(RepeatForever::create(moveAnimate));

	return hero;
}