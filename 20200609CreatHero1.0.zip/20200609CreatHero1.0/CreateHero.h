#pragma once
#ifndef __HERO_SCENE_H__
#define __HERO_SCENE_H__

#include "cocos2d.h"

cocos2d::Sprite* setKnight(float x, float y, float length);

cocos2d::Sprite* setCoolguy(float x, float y, float length);

#endif