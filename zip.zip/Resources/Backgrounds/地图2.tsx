<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="地图2" tilewidth="32" tileheight="32" tilecount="512" columns="8">
 <image source="地图2.png" width="256" height="2048"/>
 <tile id="256">
  <properties>
   <property name="Collidable" value="true"/>
  </properties>
 </tile>
</tileset>
