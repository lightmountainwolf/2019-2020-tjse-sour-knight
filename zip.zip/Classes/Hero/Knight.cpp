#include"Knight.h"



 bool Knight::init(const std::string& filename, Weapon* weapon)
{
     if (!Sprite::initWithFile(filename))
         return false;
     else
     {
         /*��ʿ��ɫ�ĳ�ʼ״̬Ϊ��
         HP��7
         Armor:6
         MP:200
         */
         setHP(HP_OF_KNIGHT);
         setArmor(ARMOR_OF_KNIGHT);
         setMP(MP_OF_KNIGHT);
         setAttackMode(weapon->getAttackMode());
         setAttackRadius(weapon->getAttackMode());
         setMPConsuming(weapon->getMPConsuming());
     }
}

 Knight* Knight::create(const std::string& filename, Weapon* weapon)
{
     Knight* knight = new Knight();
     if (knight && knight->init(filename, weapon))
     {
         knight->autorelease();
         return knight;
     }
     else
     {
         CC_SAFE_DELETE(knight);
         return nullptr;
     }
}

 Knight* Knight::create(const std::string& filename, Knight* kt)
 {
     Knight* knight = new Knight();
     if (knight&&knight->init( filename, kt))
     {
         knight->autorelease();
         return knight;
     }
     else
     {
         CC_SAFE_DELETE(knight);
         return nullptr;
     }
 }


 bool Knight::init(const std::string& filename, Knight* knight)
 {
     if (!Sprite::initWithFile(filename))
         return false;
     else
     {
         //Actor���ֳ�ʼ��
         this->setHP(knight->getHP());
         this->setAttack(knight->getAttack());
         this->setAlreadyDead(knight->getAlreadyDead());
         this->setAttackRadius(knight->getAttackRadius());
         this->setAttackMode(knight->getAttackMode());
         this->setReleaseDebuff(knight->getReleaseDebuff());
         //Hero ���ֳ�ʼ��
         this->setArmor(knight->getArmor());
         this->setMP(knight->getMP());
         this->setMPConsuming(knight->getMPConsuming());
         //Knight���ֳ�ʼ��
         return true;
     }





 }